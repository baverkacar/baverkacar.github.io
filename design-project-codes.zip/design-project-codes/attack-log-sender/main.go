package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
)

func main() {
	// Create attack logs
	attackLogs := CreateAndSaveAttackLogs()

	// Convert attack logs to JSON
	attackLogsJSON, err := json.Marshal(attackLogs)
	if err != nil {
		log.Fatalf("Error marshalling attack logs: %v", err)
	}

	// Define the API endpoint
	url := "http://localhost:8080/attack-logs"

	// Create a new POST request with the JSON body
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(attackLogsJSON))
	if err != nil {
		log.Fatalf("Error creating POST request: %v", err)
	}
	req.Header.Set("Content-Type", "application/json")

	// Send the POST request
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("Error sending POST request: %v", err)
	}
	defer func(Body io.ReadCloser) {
		err := Body.Close()
		if err != nil {

		}
	}(resp.Body)

	// Check the response status
	if resp.StatusCode != http.StatusOK {
		log.Fatalf("Received non-OK response: %s", resp.Status)
	}

	// Print the response
	fmt.Println("Attack logs sent successfully!")
}
