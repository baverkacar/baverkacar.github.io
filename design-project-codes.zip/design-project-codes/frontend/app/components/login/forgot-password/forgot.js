import "./forgot.css"

export default function  ForgotPassword() {
    return (
      <p id="forgot">Forgot Password</p>
    )
  }