import "./image.css"

export default function Image() {
    return (
      <img src="../../login.jpeg" id="login-image" alt="Login"/>
    )
}