import "./header-text.css";

export default function HeaderText() {
    return (
      <div className="header-text">
        <p id="new-member">Become a member</p>
      </div>
    )
}