import "./image.css"

export default function Image() {
    return (
      <img src="../../signup.jpeg" id="signup-image" alt="Signup"/>
    )
}