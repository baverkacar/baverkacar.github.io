import "./image.css"

export default function Image() {
    return (
      <img src="../../pass.jpeg" id="pass-image" alt="Forgot Password"/>
    )
}