import json
from datetime import datetime

suspicious = ["TCP SYN Scan", "SSH Brute Force Attack"]
susp = ""
priority = ""

ip_os_mapping = {
    "192.168.6.4": "Ubuntu",    # Victim
    "192.168.6.5": "Kali Linux", # Attacker
    "192.168.6.6": "Windows"    # Windows
}

attack_severity_map = {
    "ICMP Ping": "Allowed",
    "TCP SYN Scan": "Mid Alert",
    "SSH Brute Force Attack": "High Alert"
}


def parse_log_entry(entry):
    parts = entry.split()
    timestamp = parts[0]


    # Stringi datetime nesnesine dönüştürme
    dt = datetime.strptime(timestamp, "%m/%d/%Y-%H:%M:%S.%f")

    # Tarih ve saat parçalarını istenilen formatta elde etme
    date_part = dt.strftime("%m/%d/%Y")
    time_part = dt.strftime("%H:%M")



    protocol_start = entry.find("{")
    protocol_end = entry.find("}")
    protocol_value = entry[protocol_start + 1:protocol_end]

    src_dst_info = entry[protocol_end + 2:]
    source, dest = src_dst_info.split(" -> ")
    source_ip, source_port = source.split(":")
    dest_ip, dest_port = dest.split(":")

    type_value = ' '.join(parts[3:-9])

    if type_value not in suspicious:
        susp = "Allowed"
        priority = "Medium"
        suspicious.append(susp)
    else:
        susp = "Denied"
        priority = "High"
        suspicious.append(susp)


    log_entry = {
        "date" : date_part,
        "time" : time_part,
        "type": type_value,
        "protocol": protocol_value,
        "source_ip": source_ip,
        "source_port": source_port,
        "dest_ip": dest_ip,
        "dest_port": dest_port,
        "allow/deny": susp,
        "pritority": attack_severity_map[type_value],
        "os": ip_os_mapping[source_ip]
    }

    return log_entry


def main():
    log_entries = []
    with open("fast.log", "r") as file:
        for line in file:
            log_entries.append(line.strip())

    json_logs = []
    for entry in log_entries:
        try:
            json_logs.append(parse_log_entry(entry))
        except Exception as e:
            print("Error:", e, "- Input:", entry)

    with open("fast.json", "w") as outfile:
        json.dump(json_logs, outfile, indent=4)


if __name__ == "__main__":
    main()
